# Power-BI-Projects
This repository contains files/codes for my Data Visualization projects and reports created using Power BI.

### Files
Each folder contains the dataset(in xlsx or csv format), the dashboard (in pbix), and the dashboard converted into pdf format.
